<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('motors', function (Blueprint $table) {
        $table->id();
        $table->string('nama');
        $table->string('merek');
        $table->string('tipe');
        $table->year('tahun');
        $table->decimal('harga', 15, 2);
        $table->unsignedInteger('stok')->default(0);
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('motors');
    }
};
