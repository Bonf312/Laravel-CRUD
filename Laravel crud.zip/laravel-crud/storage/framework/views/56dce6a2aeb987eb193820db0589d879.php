

<?php $__env->startSection('title', 'Tambah Motor'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header">
        <h4 class="mb-0">Tambah Motor</h4>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('motors.store')); ?>" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('motors._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(route('motors.index')); ?>" class="btn btn-secondary">
                Kembali
            </a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/motors/create.blade.php ENDPATH**/ ?>