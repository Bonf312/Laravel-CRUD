

<?php $__env->startSection('title', 'Detail Motor'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Detail Motor</h2>

    <div class="d-flex gap-2">
        <a href="<?php echo e(route('motors.edit', $motor)); ?>"
            class="btn btn-warning">Edit</a>

        <a href="<?php echo e(route('motors.index')); ?>"
            class="btn btn-secondary">Kembali</a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <div class="row g-4">
            <div class="col-md-5">
                <?php if($motor->gambar): ?>
                    <img src="<?php echo e(asset('storage/' . $motor->gambar)); ?>"
                        alt="Foto <?php echo e($motor->nama); ?>"
                        class="img-fluid rounded"
                        style="max-height: 350px; width: 100%; object-fit: contain;">
                <?php else: ?>
                    <div class="bg-light rounded p-5 text-center">
                        <span class="text-muted">Belum ada foto motor</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-7">
                <h3><?php echo e($motor->nama); ?></h3>
                <p class="text-muted"><?php echo e($motor->merek); ?> · <?php echo e($motor->tahun); ?></p>

                <h4 class="text-primary mb-3">
                    Rp <?php echo e(number_format($motor->harga, 0, ',', '.')); ?>

                </h4>

                <p><strong>Stok:</strong> <?php echo e($motor->stok); ?> unit</p>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0">Spesifikasi Teknis</h5>
    </div>

    <div class="card-body table-responsive">
        <table class="table table-bordered align-middle mb-0">
            <tbody>
                <tr>
                    <th style="width: 40%">Kapasitas Mesin</th>
                    <td><?php echo e($motor->spesifikasi?->kapasitas_cc !== null ? $motor->spesifikasi->kapasitas_cc . ' cc' : '-'); ?></td>
                </tr>
                <tr>
                    <th>Transmisi</th>
                    <td><?php echo e($motor->spesifikasi?->transmisi ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Bahan Bakar</th>
                    <td><?php echo e($motor->spesifikasi?->bahan_bakar ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Berat Motor</th>
                    <td><?php echo e($motor->spesifikasi?->berat_motor !== null ? $motor->spesifikasi->berat_motor . ' kg' : '-'); ?></td>
                </tr>
                <tr>
                    <th>Kapasitas Tangki</th>
                    <td><?php echo e($motor->spesifikasi?->kapasitas_tangki !== null ? $motor->spesifikasi->kapasitas_tangki . ' liter' : '-'); ?></td>
                </tr>
                <tr>
                    <th>Rem ABS</th>
                    <td><?php echo e($motor->spesifikasi ? ($motor->spesifikasi->rem_abs ? 'Ya' : 'Tidak') : '-'); ?></td>
                </tr>
                <tr>
                    <th>Sistem Pendingin</th>
                    <td><?php echo e($motor->spesifikasi?->sistem_pendingin ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Tenaga Mesin</th>
                    <td><?php echo e($motor->spesifikasi?->tenaga_mesin !== null ? $motor->spesifikasi->tenaga_mesin . ' PS' : '-'); ?></td>
                </tr>
                <tr>
                    <th>Torsi</th>
                    <td><?php echo e($motor->spesifikasi?->torsi !== null ? $motor->spesifikasi->torsi . ' Nm' : '-'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/motors/show.blade.php ENDPATH**/ ?>