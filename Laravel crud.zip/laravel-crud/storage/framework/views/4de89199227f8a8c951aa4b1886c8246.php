<div class="row">
    <div class="col-md-6 mb-3">
        <label class="form-label">Nama Motor</label>
        <input type="text" name="nama" class="form-control"
            value="<?php echo e(old('nama', $motor->nama)); ?>" required>
        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6 mb-3">
        <label class="form-label">Merek</label>
        <input type="text" name="merek" class="form-control"
            value="<?php echo e(old('merek', $motor->merek)); ?>" required>
        <?php $__errorArgs = ['merek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

<div class="mb-3">
    <label for="tipe" class="form-label">Tipe Motor</label>

    <select name="tipe" id="tipe" class="form-select" required>
        <option value="">Pilih Tipe Motor</option>
        <option value="Matic" <?php if(old('tipe', $motor->tipe) == 'Matic'): echo 'selected'; endif; ?>>
            Matic
        </option>
        <option value="Sport" <?php if(old('tipe', $motor->tipe) == 'Sport'): echo 'selected'; endif; ?>>
            Sport
        </option>
        <option value="Bebek" <?php if(old('tipe', $motor->tipe) == 'Bebek'): echo 'selected'; endif; ?>>
            Bebek
        </option>
    </select>

    <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Tahun</label>
        <input type="number" name="tahun" class="form-control"
            value="<?php echo e(old('tahun', $motor->tahun)); ?>"
            min="1900" max="2100" required>
        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Harga (Rp)</label>
        <input type="number" name="harga" class="form-control"
            value="<?php echo e(old('harga', $motor->harga)); ?>"
            min="0" step="0.01" required>
        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Stok</label>
        <input type="number" name="stok" class="form-control"
            value="<?php echo e(old('stok', $motor->stok ?? 0)); ?>"
            min="0" required>
        <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-12 mb-3">
        <label class="form-label">Foto Motor</label>
        <input type="file" name="gambar" class="form-control"
            accept=".jpg,.jpeg,.png,.webp">

        <div class="form-text">JPG, JPEG, PNG, atau WEBP. Maksimal 2 MB.</div>
        <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if(request()->routeIs('motors.edit') && $motor->gambar): ?>
    <div class="mt-2">
        <p class="mb-1">Foto saat ini:</p>
        <img src="<?php echo e(asset('storage/' . $motor->gambar)); ?>"
            alt="Foto motor"
            class="img-thumbnail"
            style="max-width: 220px; max-height: 160px; object-fit: contain;">
    </div>
<?php endif; ?>
    </div>
</div>

<hr>
<h5 class="mb-3">Spesifikasi Motor</h5>

<?php
    $sp = $motor->spesifikasi;
?>

<div class="row">
    <div class="col-md-4 mb-3">
        <label class="form-label">Kapasitas Mesin (CC)</label>
        <input type="number" name="spesifikasi[kapasitas_cc]"
            class="form-control" min="0"
            value="<?php echo e(old('spesifikasi.kapasitas_cc', $sp?->kapasitas_cc)); ?>">
        <?php $__errorArgs = ['spesifikasi.kapasitas_cc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Transmisi</label>
        <select name="spesifikasi[transmisi]" class="form-select">
            <option value="">-- Pilih transmisi --</option>
            <?php $__currentLoopData = ['Otomatis', 'Manual', 'Semi otomatis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>"
                    <?php if(old('spesifikasi.transmisi', $sp?->transmisi) === $item): echo 'selected'; endif; ?>>
                    <?php echo e($item); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['spesifikasi.transmisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Bahan Bakar</label>
        <select name="spesifikasi[bahan_bakar]" class="form-select">
            <option value="">-- Pilih bahan bakar --</option>
            <?php $__currentLoopData = ['Bensin', 'Listrik', 'Hybrid']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>"
                    <?php if(old('spesifikasi.bahan_bakar', $sp?->bahan_bakar) === $item): echo 'selected'; endif; ?>>
                    <?php echo e($item); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['spesifikasi.bahan_bakar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Berat Motor (kg)</label>
        <input type="number" step="0.01" min="0"
            name="spesifikasi[berat_motor]" class="form-control"
            value="<?php echo e(old('spesifikasi.berat_motor', $sp?->berat_motor)); ?>">
        <?php $__errorArgs = ['spesifikasi.berat_motor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Kapasitas Tangki (liter)</label>
        <input type="number" step="0.01" min="0"
            name="spesifikasi[kapasitas_tangki]" class="form-control"
            value="<?php echo e(old('spesifikasi.kapasitas_tangki', $sp?->kapasitas_tangki)); ?>">
        <?php $__errorArgs = ['spesifikasi.kapasitas_tangki'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Rem ABS</label>
        <select name="spesifikasi[rem_abs]" class="form-select">
            <option value="0"
                <?php if((string) old('spesifikasi.rem_abs', (int) ($sp?->rem_abs ?? false)) === '0'): echo 'selected'; endif; ?>>
                Tidak
            </option>
            <option value="1"
                <?php if((string) old('spesifikasi.rem_abs', (int) ($sp?->rem_abs ?? false)) === '1'): echo 'selected'; endif; ?>>
                Ya
            </option>
        </select>
        <?php $__errorArgs = ['spesifikasi.rem_abs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Sistem Pendingin</label>
        <select name="spesifikasi[sistem_pendingin]" class="form-select">
            <option value="">-- Pilih sistem --</option>
            <?php $__currentLoopData = ['Udara', 'Cairan', 'Oli']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item); ?>"
                    <?php if(old('spesifikasi.sistem_pendingin', $sp?->sistem_pendingin) === $item): echo 'selected'; endif; ?>>
                    <?php echo e($item); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['spesifikasi.sistem_pendingin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Tenaga Mesin (PS)</label>
        <input type="number" step="0.01" min="0"
            name="spesifikasi[tenaga_mesin]" class="form-control"
            value="<?php echo e(old('spesifikasi.tenaga_mesin', $sp?->tenaga_mesin)); ?>">
        <?php $__errorArgs = ['spesifikasi.tenaga_mesin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-4 mb-3">
        <label class="form-label">Torsi (Nm)</label>
        <input type="number" step="0.01" min="0"
            name="spesifikasi[torsi]" class="form-control"
            value="<?php echo e(old('spesifikasi.torsi', $sp?->torsi)); ?>">
        <?php $__errorArgs = ['spesifikasi.torsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div><?php /**PATH C:\laragon\www\laravel-crud\resources\views/motors/_form.blade.php ENDPATH**/ ?>