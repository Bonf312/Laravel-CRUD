


<?php $__env->startSection('title', 'Katalog Motor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="d-flex flex-wrap justify-content-between
        align-items-center gap-3 mb-4">
        <div>
            <h2 class="fw-bold mb-1">LARAVEL CRUD MOTOR</h2>
            <p class="text-secondary mb-0">
                Kelola dan temukan motor dengan mudah.
            </p>
        </div>

        <a href="<?php echo e(route('motors.create')); ?>"
            class="btn btn-primary">
            <i class="bi bi-plus-lg"></i>
            Tambah Motor
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close"
                data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('motors.index')); ?>"
                method="GET">
                <div class="row g-2">
                    <div class="col-md-10">
                        <input type="search"
                            name="search"
                            class="form-control form-control-lg"
                            placeholder="Cari nama, merek, tipe, atau tahun motor..."
                            value="<?php echo e($search ?? ''); ?>">
                    </div>

                    <div class="col-md-2 d-grid">
                        <button type="submit"
                            class="btn btn-primary btn-lg">
                            <i class="bi bi-search"></i>
                            Cari
                        </button>
                    </div>
                </div>

                <?php if(!empty($search)): ?>
                    <div class="mt-2">
                        <span class="text-secondary small">
                            Kata pencarian: "<?php echo e($search); ?>"
                        </span>
                        <a href="<?php echo e(route('motors.index')); ?>"
                            class="small ms-2 text-decoration-none">
                            Hapus pencarian
                        </a>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    
    <div class="d-flex justify-content-between
        align-items-center mb-3">
        <h5 class="fw-semibold mb-0">Daftar Motor</h5>
        <span class="badge text-bg-light border">
            <?php echo e($motors->total()); ?> motor
        </span>
    </div>

    
    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $motors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                <div class="card h-100 border-0 shadow-sm
                    motor-card">

                    <?php if($motor->gambar): ?>
                        <img
                            src="<?php echo e(asset('storage/' . $motor->gambar)); ?>"
                            class="card-img-top motor-image"
                            alt="<?php echo e($motor->nama); ?>">
                    <?php else: ?>
                        <div class="motor-image-placeholder
                            d-flex align-items-center justify-content-center">
                            <i class="bi bi-bicycle display-3
                                text-secondary"></i>
                        </div>
                    <?php endif; ?>

                    <div class="card-body d-flex flex-column">
                        <span class="badge text-bg-light border
                            align-self-start mb-2">
                            <?php echo e($motor->tipe); ?>

                        </span>

                        <h5 class="card-title fw-bold">
                            <?php echo e($motor->nama); ?>

                        </h5>

                        <p class="text-secondary mb-2">
                            <?php echo e($motor->merek); ?>

                            · Tahun <?php echo e($motor->tahun); ?>

                        </p>

                        <h5 class="text-primary fw-bold mb-2">
                            Rp <?php echo e(number_format(
                                $motor->harga, 0, ',', '.'
                            )); ?>

                        </h5>

                        <p class="small text-secondary mb-3">
                            Stok: <?php echo e($motor->stok); ?>

                        </p>

                        <div class="mt-auto d-flex flex-wrap gap-2">
                            <a href="<?php echo e(route('motors.show', $motor->id)); ?>"
                                class="btn btn-outline-primary btn-sm flex-fill">
                                Detail
                            </a>

                            <a href="<?php echo e(route('motors.edit', $motor->id)); ?>"
                                class="btn btn-outline-warning btn-sm flex-fill">
                                Edit
                            </a>

                            <form
                                action="<?php echo e(route('motors.destroy', $motor->id)); ?>"
                                method="POST"
                                class="d-inline"
                                onsubmit="return confirm('Yakin ingin menghapus motor ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit"
                                    class="btn btn-outline-danger btn-sm flex-fill">
                                    <i class="bi bi-trash"></i>Hapus
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-search display-4
                            text-secondary"></i>

                        <h5 class="mt-3">Motor tidak ditemukan</h5>

                        <p class="text-secondary">
                            Coba gunakan nama, merek, tipe,
                            atau tahun yang berbeda.
                        </p>

                        <a href="<?php echo e(route('motors.index')); ?>"
                            class="btn btn-outline-primary">
                            Tampilkan Semua Motor
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    
    <?php if($motors->hasPages()): ?>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($motors->links()); ?>

        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/motors/index.blade.php ENDPATH**/ ?>